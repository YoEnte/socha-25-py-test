from xsdata.codegen.parsers.definitions import DefinitionsParser
from xsdata.codegen.parsers.schema import SchemaParser

__all__ = ["SchemaParser", "DefinitionsParser"]
